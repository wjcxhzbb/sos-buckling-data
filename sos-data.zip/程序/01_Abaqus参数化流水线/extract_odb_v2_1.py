"""Minimal ODB validation/extraction for v2_1.

The linear BUCKLE stage intentionally does not infer static 1 MPa stress fields.
This script opens the ODB, extracts mode displacement ratios when available, and
returns an explicit DEFERRED stress status.
"""
from __future__ import print_function

import argparse
import json
import math
import os


def vector_magnitude(data):
    return math.sqrt(sum(float(x) * float(x) for x in data))


def max_displacement(field):
    maximum = 0.0
    for value in field.values:
        data = getattr(value, "data", None)
        if data is None:
            continue
        maximum = max(maximum, vector_magnitude(data))
    return maximum


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--odb", required=True)
    parser.add_argument("--output", required=True)
    args = parser.parse_args()
    payload = {
        "odb_path": os.path.abspath(args.odb),
        "odb_opened": False,
        "mode_displacement_ratios": [],
        "shell_max_mises_1MPa": "",
        "endplate_max_mises_1MPa": "",
        "stress_status": "DEFERRED",
        "warning_message": "Stress extraction deferred; no static 1 MPa analysis was run.",
    }
    try:
        from odbAccess import openOdb
        odb = openOdb(path=args.odb, readOnly=True)
        payload["odb_opened"] = True
        step = odb.steps["BUCKLE"] if "BUCKLE" in odb.steps.keys() else None
        if step is not None:
            for frame in step.frames:
                field = frame.fieldOutputs["U"] if "U" in frame.fieldOutputs.keys() else None
                if field is not None:
                    payload["mode_displacement_ratios"].append(max_displacement(field))
        odb.close()
    except Exception as exc:
        payload["warning_message"] = "ODB open/extraction failed: %s" % exc
    with open(args.output, "w") as stream:
        json.dump(payload, stream, indent=2, sort_keys=True)
    print(json.dumps(payload, sort_keys=True))


if __name__ == "__main__":
    main()
