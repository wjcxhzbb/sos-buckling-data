"""Isolated v2.1 Abaqus pipeline with paper-aligned supports and plate mesh."""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import os
import re
import subprocess
import sys
import time
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Iterable, Optional

ROOT = Path(__file__).resolve().parent
CONFIG_PATH = ROOT / "config_v2_1.json"
SAMPLE_GENERATOR = ROOT / "prepare_controlled_study.py"
EXTRACT_SCRIPT = ROOT / "extract_odb_v2_1.py"
MODEL_VERSION = "parametric_v2_1_paper_boundary_mesh_repair"
DECIMALS = 5

# The v2 geometry utilities are read-only dependencies. v2 files and outputs
# are never written by this script.
sys.path.insert(0, str(ROOT))
import run_pipeline_v2 as legacy  # noqa: E402


@dataclass(frozen=True)
class Sample:
    sample_id: int
    tmin: float
    wave_count: int
    amplitude: float
    diameter: float
    length: float
    endplate_diameter: float
    endplate_thickness: float

    @property
    def rout(self) -> float:
        return self.diameter / 2.0

    @property
    def tavg(self) -> float:
        return self.tmin + self.amplitude

    @property
    def tmax(self) -> float:
        return self.tmin + 2.0 * self.amplitude


def load_config() -> dict:
    return json.loads(CONFIG_PATH.read_text(encoding="utf-8"))


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def output_paths(cfg: dict) -> dict[str, Path]:
    root = ROOT / cfg["outputs"]["root"]
    return {
        "root": root,
        "samples": root / cfg["outputs"]["samples_csv"],
        "results": root / cfg["outputs"]["results_csv"],
        "logs": root / cfg["outputs"]["logs_dir"],
        "work": root / cfg["outputs"]["work_dir"],
        "inp": root / cfg["outputs"]["inp_dir"],
        "odb": root / cfg["outputs"]["odb_dir"],
        "fingerprint": root / cfg["outputs"]["fingerprint_file"],
    }


def ensure_dirs(paths: dict[str, Path]) -> None:
    for key in ("root", "logs", "work", "inp", "odb"):
        paths[key].mkdir(parents=True, exist_ok=True)


def log(paths: dict[str, Path], message: str, sample_id: Optional[int] = None) -> None:
    stamp = time.strftime("%Y-%m-%d %H:%M:%S")
    line = f"[{stamp}] {message}"
    print(line)
    target = paths["root"] / "pipeline_v2_1.log" if sample_id is None else paths["logs"] / f"sample_{sample_id:03d}.log"
    with target.open("a", encoding="utf-8") as stream:
        stream.write(line + "\n")


def read_samples(path: Path) -> list[Sample]:
    rows = []
    with path.open(encoding="utf-8-sig", newline="") as stream:
        for row in csv.DictReader(stream):
            rows.append(Sample(int(row["ID"]), float(row["tmin_mm"]), int(row["N"]), float(row["s_amplitude_mm"]), float(row["D_mm"]), float(row["L_mm"]), float(row["endplate_diameter_mm"]), float(row["endplate_thickness_mm"])))
    return rows


def validate_samples(samples: list[Sample], cfg: dict) -> None:
    if len(samples) != cfg["num_samples"] or [s.sample_id for s in samples] != list(range(cfg["num_samples"])):
        raise ValueError("samples_v2_1.csv must contain IDs 0..599 exactly")
    if (samples[0].tmin, samples[0].wave_count, samples[0].amplitude) != (1.0, 5, 1.0):
        raise ValueError("ID=0 baseline is not tmin=1, N=5, s=1")
    tlo, thi = cfg["design_ranges"]["tmin_mm"]
    alo, ahi = cfg["design_ranges"]["s_amplitude_mm"]
    nlo, nhi = cfg["design_ranges"]["N"]
    for s in samples:
        if not (tlo <= s.tmin <= thi and alo <= s.amplitude <= ahi and nlo <= s.wave_count <= nhi):
            raise ValueError(f"sample outside configured range: {s.sample_id}")


def t_of_z(sample: Sample, z: float) -> float:
    return sample.tmin + sample.amplitude + sample.amplitude * math.sin(2.0 * math.pi * sample.wave_count * z / sample.length)


def r_in(sample: Sample, z: float) -> float:
    return sample.rout - t_of_z(sample, z)


def choose_mesh_counts(sample: Sample, cfg: dict) -> tuple[int, int]:
    return legacy.choose_mesh_counts(sample, cfg)


def square_to_disk(u: float, v: float, radius: float) -> tuple[float, float]:
    if abs(u) < 1e-14 and abs(v) < 1e-14:
        return 0.0, 0.0
    if abs(u) > abs(v):
        radial = u
        phi = math.pi * v / (4.0 * u)
    else:
        radial = v
        phi = math.pi / 2.0 - math.pi * u / (4.0 * v)
    return radius * radial * math.cos(phi), radius * radial * math.sin(phi)


def build_plate_mesh(start_node: int, start_element: int, radius: float, nu: int, nv: int, z: float) -> dict:
    nodes, node_map = [], {}
    node_id = start_node
    for j in range(nv + 1):
        for i in range(nu + 1):
            u = (i - nu / 2.0) / (nu / 2.0)
            v = (j - nv / 2.0) / (nv / 2.0)
            x, y = square_to_disk(u, v, radius)
            node_map[(i, j)] = node_id
            nodes.append((node_id, x, y, z))
            node_id += 1
    elements = []
    element_id = start_element
    for j in range(nv):
        for i in range(nu):
            elements.append((element_id, node_map[(i, j)], node_map[(i + 1, j)], node_map[(i + 1, j + 1)], node_map[(i, j + 1)]))
            element_id += 1
    return {"nodes": nodes, "elements": elements, "node_ids": [n[0] for n in nodes], "node_map": node_map, "nu": nu, "nv": nv}


def build_model_mesh(sample: Sample, cfg: dict) -> dict:
    n_axial, n_circ = choose_mesh_counts(sample, cfg)
    n_thick = int(cfg["mesh"]["thickness_layers"])
    dtheta = 2.0 * math.pi / n_circ
    nodes, shell_map = [], {}
    next_node = 1
    z_coords = [sample.length * i / n_axial for i in range(n_axial + 1)]
    for ia, z in enumerate(z_coords):
        rin = r_in(sample, z)
        thickness = sample.rout - rin
        for ic in range(n_circ):
            theta = ic * dtheta
            for it in range(n_thick + 1):
                radius = rin + it / float(n_thick) * thickness
                shell_map[(ia, ic, it)] = next_node
                nodes.append((next_node, radius * math.cos(theta), radius * math.sin(theta), z))
                next_node += 1
    solid, outer, left_face, right_face, volumes = [], [], [], [], []
    next_element = 1
    for ia in range(n_axial):
        z0, z1 = z_coords[ia], z_coords[ia + 1]
        dz = z1 - z0
        rin0, rin1 = r_in(sample, z0), r_in(sample, z1)
        t0, t1 = sample.rout - rin0, sample.rout - rin1
        for ic in range(n_circ):
            ic2 = (ic + 1) % n_circ
            for it in range(n_thick):
                e = (next_element, shell_map[(ia, ic, it)], shell_map[(ia, ic2, it)], shell_map[(ia + 1, ic2, it)], shell_map[(ia + 1, ic, it)], shell_map[(ia, ic, it + 1)], shell_map[(ia, ic2, it + 1)], shell_map[(ia + 1, ic2, it + 1)], shell_map[(ia + 1, ic, it + 1)])
                solid.append(e)
                if it == n_thick - 1: outer.append(next_element)
                if ia == 0: left_face.append(next_element)
                if ia == n_axial - 1: right_face.append(next_element)
                low0, low1 = rin0 + it / n_thick * t0, rin1 + it / n_thick * t1
                high0, high1 = rin0 + (it + 1) / n_thick * t0, rin1 + (it + 1) / n_thick * t1
                volumes.append(0.5 * dtheta * dz * ((high0 * high0 + high0 * high1 + high1 * high1) - (low0 * low0 + low0 * low1 + low1 * low1)) / 3.0)
                next_element += 1
    nu, nv = int(cfg["mesh"]["endplate_grid_u"]), int(cfg["mesh"]["endplate_grid_v"])
    radius = sample.endplate_diameter / 2.0
    left = build_plate_mesh(next_node, next_element, radius, nu, nv, -sample.endplate_thickness / 2.0)
    next_node = left["nodes"][-1][0] + 1
    next_element = left["elements"][-1][0] + 1
    right = build_plate_mesh(next_node, next_element, radius, nu, nv, sample.length + sample.endplate_thickness / 2.0)
    nodes.extend(left["nodes"] + right["nodes"])
    plate_elements = left["elements"] + right["elements"]
    left_end = left["node_map"][(nu, nv // 2)]
    right_end = right["node_map"][(nu, nv // 2)]
    mid_shell = shell_map[(n_axial // 2, n_circ // 4, n_thick)]
    return {
        "nodes": nodes, "solid_elements": solid, "plate_elements": plate_elements,
        "shell_element_ids": [e[0] for e in solid], "plate_element_ids": [e[0] for e in plate_elements],
        "left_plate_elements": [e[0] for e in left["elements"]], "right_plate_elements": [e[0] for e in right["elements"]],
        "shell_node_ids": [n[0] for n in nodes[: len(shell_map)]], "plate_node_ids": [n[0] for n in left["nodes"] + right["nodes"]],
        "left_plate_node_ids": left["node_ids"], "right_plate_node_ids": right["node_ids"],
        "shell_outer_face_elements": outer, "shell_left_face_elements": left_face, "shell_right_face_elements": right_face,
        "support": {"MID_UPPER": mid_shell, "LEFT_END": left_end, "RIGHT_END": right_end},
        "n_axial": n_axial, "n_circ": n_circ, "n_thick": n_thick, "shell_element_volumes": volumes,
        "plate_grid_u": nu, "plate_grid_v": nv,
    }


def write_ids(stream, values: Iterable[int], per_line: int = 16) -> None:
    values = list(values)
    for i in range(0, len(values), per_line):
        stream.write(", ".join(str(v) for v in values[i:i + per_line]) + "\n")


def write_set(stream, kind: str, name: str, values: Iterable[int], instance: Optional[str] = None) -> None:
    suffix = f", instance={instance}" if instance else ""
    stream.write(f"*{kind}, {kind.lower()}={name}{suffix}\n")
    write_ids(stream, values)


def write_inp(sample: Sample, mesh: dict, cfg: dict, out_path: Path) -> None:
    mat, load, solver = cfg["material"], cfg["load"], cfg["solver"]
    with out_path.open("w", encoding="utf-8", newline="\n") as stream:
        stream.write("*Heading\n** v2_1 paper-aligned boundary and 5760-element endplates\n")
        stream.write(f"** sample={sample.sample_id}; t(z)=tmin+s+s*sin(2*pi*N*z/L); model_version={MODEL_VERSION}\n")
        stream.write(f"** config_sha256={sha256_file(CONFIG_PATH)}\n")
        stream.write("*Preprint, echo=NO, model=NO, history=NO, contact=NO\n*Part, name=MODEL\n*Node\n")
        for nid, x, y, z in mesh["nodes"]: stream.write(f"{nid}, {x:.10f}, {y:.10f}, {z:.10f}\n")
        stream.write("*Element, type=C3D8R\n")
        for e in mesh["solid_elements"]: stream.write(f"{e[0]}, {', '.join(map(str, e[1:]))}\n")
        stream.write("*Element, type=S4R\n")
        for e in mesh["plate_elements"]: stream.write(f"{e[0]}, {', '.join(map(str, e[1:]))}\n")
        write_set(stream, "Nset", "SHELL_NODES", mesh["shell_node_ids"])
        write_set(stream, "Nset", "PLATE_NODES", mesh["plate_node_ids"])
        for name, nid in mesh["support"].items(): write_set(stream, "Nset", f"SUPPORT_{name}", [nid])
        write_set(stream, "Elset", "SHELL_ELEMS", mesh["shell_element_ids"])
        write_set(stream, "Elset", "PLATE_ELEMS", mesh["plate_element_ids"])
        write_set(stream, "Elset", "PLATE_LEFT_ELEMS", mesh["left_plate_elements"])
        write_set(stream, "Elset", "PLATE_RIGHT_ELEMS", mesh["right_plate_elements"])
        stream.write(f"*Solid Section, elset=SHELL_ELEMS, material={mat['name']}\n,\n*Shell Section, elset=PLATE_ELEMS, material={mat['name']}\n{sample.endplate_thickness:.10f},\n*End Part\n")
        stream.write(f"*Material, name={mat['name']}\n*Density\n{float(mat['density_tonne_per_mm3']):.12g}\n*Elastic\n{float(mat['E_MPa']):.10f}, {float(mat['nu']):.10f}\n")
        stream.write("*Assembly, name=ASSEMBLY\n*Instance, name=MODEL_INST, part=MODEL\n*End Instance\n")
        for name, nid in mesh["support"].items(): write_set(stream, "Nset", f"SUPPORT_{name}_INST", [nid], "MODEL_INST")
        write_set(stream, "Nset", "SHELL_NODES_INST", mesh["shell_node_ids"], "MODEL_INST")
        write_set(stream, "Nset", "PLATE_NODES_INST", mesh["plate_node_ids"], "MODEL_INST")
        write_set(stream, "Elset", "SHELL_ELEMS_INST", mesh["shell_element_ids"], "MODEL_INST")
        write_set(stream, "Elset", "PLATE_ELEMS_INST", mesh["plate_element_ids"], "MODEL_INST")
        write_set(stream, "Elset", "SHELL_OUTER_FACE_ELEMS", mesh["shell_outer_face_elements"], "MODEL_INST")
        write_set(stream, "Elset", "SHELL_LEFT_FACE_ELEMS", mesh["shell_left_face_elements"], "MODEL_INST")
        write_set(stream, "Elset", "SHELL_RIGHT_FACE_ELEMS", mesh["shell_right_face_elements"], "MODEL_INST")
        write_set(stream, "Elset", "PLATE_LEFT_ELEMS_INST", mesh["left_plate_elements"], "MODEL_INST")
        write_set(stream, "Elset", "PLATE_RIGHT_ELEMS_INST", mesh["right_plate_elements"], "MODEL_INST")
        stream.write("*Surface, type=ELEMENT, name=SHELL_OUTER\nSHELL_OUTER_FACE_ELEMS, S2\n*Surface, type=ELEMENT, name=SHELL_LEFT_TIE\nSHELL_LEFT_FACE_ELEMS, S3\n*Surface, type=ELEMENT, name=SHELL_RIGHT_TIE\nSHELL_RIGHT_FACE_ELEMS, S5\n")
        stream.write("*Surface, type=ELEMENT, name=PLATE_LEFT_INNER\nPLATE_LEFT_ELEMS_INST, SPOS\n*Surface, type=ELEMENT, name=PLATE_RIGHT_INNER\nPLATE_RIGHT_ELEMS_INST, SNEG\n*Surface, type=ELEMENT, name=PLATE_LEFT_OUTER\nPLATE_LEFT_ELEMS_INST, SNEG\n*Surface, type=ELEMENT, name=PLATE_RIGHT_OUTER\nPLATE_RIGHT_ELEMS_INST, SPOS\n")
        stream.write("*Tie, name=TIE_LEFT, position tolerance=0.25\nSHELL_LEFT_TIE, PLATE_LEFT_INNER\n*Tie, name=TIE_RIGHT, position tolerance=0.25\nSHELL_RIGHT_TIE, PLATE_RIGHT_INNER\n*End Assembly\n")
        stream.write("** Fig.12 mapping: MID_UPPER U1,U3; LEFT_END U1,U2; RIGHT_END U1,U2.\n*Boundary\n")
        stream.write("SUPPORT_MID_UPPER_INST, 1, 1, 0.0\nSUPPORT_MID_UPPER_INST, 3, 3, 0.0\nSUPPORT_LEFT_END_INST, 1, 2, 0.0\nSUPPORT_RIGHT_END_INST, 1, 2, 0.0\n")
        stream.write("*Step, name=BUCKLE, nlgeom=NO, perturbation\n*Buckle, eigensolver=Subspace\n")
        stream.write(f"{int(solver['buckle_modes'])}, , {int(solver['buckle_vectors'])}, {int(solver['buckle_max_iterations'])}\n*Dsload\n")
        p = float(load["reference_pressure_MPa"])
        stream.write(f"SHELL_OUTER, P, {p:.10f}\nPLATE_LEFT_OUTER, P, {p:.10f}\nPLATE_RIGHT_OUTER, P, {p:.10f}\n*Output, field\n*Node Output\nU\n*End Step\n")


def polygon_area(points: list[tuple[float, float]]) -> float:
    return 0.5 * sum(points[i][0] * points[(i + 1) % len(points)][1] - points[(i + 1) % len(points)][0] * points[i][1] for i in range(len(points)))


def mesh_diagnostics(sample: Sample, mesh: dict) -> dict:
    node_map = {n[0]: n for n in mesh["nodes"]}
    areas, aspects, negative = [], [], 0
    for e in mesh["plate_elements"]:
        pts = [(node_map[n][1], node_map[n][2]) for n in e[1:]]
        signed = polygon_area(pts)
        if signed <= 0.0: negative += 1
        areas.append(abs(signed))
        edges = [math.dist(pts[i], pts[(i + 1) % 4]) for i in range(4)]
        aspects.append(max(edges) / max(min(edges), 1e-12))
    total_plate_nodes = len(mesh["plate_node_ids"])
    element_map = {e[0]: e for e in mesh["solid_elements"]}
    left_nodes = set()
    right_nodes = set()
    for eid in mesh["shell_left_face_elements"]:
        e = element_map[eid]
        left_nodes.update((e[1], e[2], e[5], e[6]))
    for eid in mesh["shell_right_face_elements"]:
        e = element_map[eid]
        right_nodes.update((e[3], e[4], e[7], e[8]))
    tie_secondary = len(left_nodes) + len(right_nodes)
    return {
        "n_axial": mesh["n_axial"], "n_circumferential": mesh["n_circ"], "thickness_layers": mesh["n_thick"],
        "nodes": len(mesh["nodes"]), "elements": len(mesh["solid_elements"]) + len(mesh["plate_elements"]),
        "shell_elements": len(mesh["solid_elements"]), "endplate_elements": len(mesh["plate_elements"]),
        "endplate_nodes_each": total_plate_nodes // 2, "endplate_elements_each": len(mesh["plate_elements"]) // 2,
        "endplate_area_min_mm2": min(areas), "endplate_area_max_mm2": max(areas), "endplate_max_aspect": max(aspects),
        "endplate_negative_area_count": negative, "tie_secondary_node_count_estimate": tie_secondary,
        "tie_geometry_check": "PASS: shell end faces are coincident with endplate inner reference surfaces",
        "shell_surface_edge_mm": 2.0 * math.pi * (sample.rout - 0.5 * sample.tavg) / mesh["n_circ"],
        "axial_edge_mm": sample.length / mesh["n_axial"],
    }


def rigid_rank(mesh: dict) -> int:
    node_map = {n[0]: n for n in mesh["nodes"]}
    rows = []
    constraints = [("MID_UPPER", "U1"), ("MID_UPPER", "U3"), ("LEFT_END", "U1"), ("LEFT_END", "U2"), ("RIGHT_END", "U1"), ("RIGHT_END", "U2")]
    for name, dof in constraints:
        _, x, y, z = node_map[mesh["support"][name]]
        rows.append({"U1": [1, 0, 0, 0, z, -y], "U2": [0, 1, 0, -z, 0, x], "U3": [0, 0, 1, y, -x, 0]}[dof])
    rank = 0
    for col in range(6):
        pivot = next((i for i in range(rank, len(rows)) if abs(rows[i][col]) > 1e-10), None)
        if pivot is None: continue
        rows[rank], rows[pivot] = rows[pivot], rows[rank]
        scale = rows[rank][col]
        rows[rank] = [v / scale for v in rows[rank]]
        for i in range(len(rows)):
            if i != rank and abs(rows[i][col]) > 1e-10:
                factor = rows[i][col]
                rows[i] = [a - factor * b for a, b in zip(rows[i], rows[rank])]
        rank += 1
    return rank


def support_metadata(mesh: dict) -> dict:
    node_map = {n[0]: n for n in mesh["nodes"]}
    meta = {"boundary_rank": rigid_rank(mesh), "boundary_expected_rank": 6, "boundary_rank_status": "PASS" if rigid_rank(mesh) == 6 else "FAILED"}
    dofs = {"MID_UPPER": "U1,U3", "LEFT_END": "U1,U2", "RIGHT_END": "U1,U2"}
    locations = {"MID_UPPER": "shell outer surface, z=L/2, theta=90deg", "LEFT_END": "left endplate boundary, theta=0deg", "RIGHT_END": "right endplate boundary, theta=0deg"}
    for name, nid in mesh["support"].items():
        node = node_map[nid]
        meta[f"support_{name}_node"] = nid
        meta[f"support_{name}_xyz"] = ";".join(f"{v:.6f}" for v in node[1:])
        meta[f"support_{name}_dofs"] = dofs[name]
        meta[f"support_{name}_physical_location"] = locations[name]
    return meta


def parse_eigenvalues(dat_path: Path) -> list[float]:
    if not dat_path.exists(): return []
    text = dat_path.read_text(encoding="utf-8", errors="ignore")
    number = r"[+-]?(?:\d+(?:\.\d*)?|\.\d+)(?:[Ee][+-]?\d+)?"
    values = []
    in_table = False
    for line in text.splitlines():
        upper = line.upper()
        if "MODE" in upper and "EIGENVALUE" in upper: in_table = True; continue
        if in_table:
            match = re.match(rf"^\s*\d+\s+({number})", line)
            if match: values.append(float(match.group(1))); continue
            if values and (not line.strip() or "EIGENVALUE" not in upper): break
    return values


def valid_eigenvalues(raw: list[float], threshold: float) -> list[float]:
    return [v for v in raw if math.isfinite(v) and v > threshold][:3]


def run_abaqus(job: str, inp: Path, work: Path, cfg: dict) -> tuple[bool, str]:
    cmd = str(cfg["solver"]["abaqus_command"])
    try:
        result = subprocess.run(f"{cmd} job={job} input={inp.name} interactive", cwd=str(work), shell=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, check=False)
        out = result.stdout or ""
        bad = any(x in out.upper() for x in ("EXITS WITH AN ERROR", "ABAQUS ERROR:", "EXITED WITH ERROR"))
        return result.returncode == 0 and not bad, out
    except Exception as exc:
        return False, str(exc)


def artifact_check(job: str, work: Path, odb: Path, raw: list[float], cfg: dict) -> tuple[bool, str]:
    sta, dat, msg = work / f"{job}.sta", work / f"{job}.dat", work / f"{job}.msg"
    if not sta.exists() or "THE ANALYSIS HAS COMPLETED SUCCESSFULLY" not in sta.read_text(errors="ignore").upper(): return False, "missing STA completion marker"
    dat_text = dat.read_text(errors="ignore") if dat.exists() else ""
    if "ANALYSIS COMPLETE" not in dat_text.upper(): return False, "missing DAT completion marker"
    if "***ERROR" in dat_text.upper() or (msg.exists() and "***ERROR" in msg.read_text(errors="ignore").upper()): return False, "solver artifact contains ***ERROR"
    if not odb.exists() or odb.stat().st_size == 0: return False, "ODB missing or empty"
    if len(valid_eigenvalues(raw, float(cfg["solver"]["min_physical_eigenvalue"]))) < 3: return False, "fewer than three positive eigenvalues after filter"
    return True, ""


RESULT_FIELDS = ["ID", "tmin_mm", "N", "s_amplitude_mm", "mass_kg", "eigenvalue_1", "eigenvalue_2", "eigenvalue_3", "raw_eigenvalues", "status", "failure_type", "failure_message", "warning_message", "stress_status", "model_version", "config_sha256", "sample_generator_sha256", "pipeline_sha256", "extractor_sha256", "samples_sha256", "inp_sha256", "model_fingerprint", "abaqus_version", "n_axial", "n_circumferential", "endplate_elements_each", "endplate_nodes_each", "endplate_area_min_mm2", "endplate_area_max_mm2", "endplate_max_aspect", "endplate_negative_area_count", "boundary_rank", "boundary_rank_status", "tie_secondary_node_count_estimate", "tie_geometry_check", "odb_opened"]


def atomic_csv(path: Path, rows: list[dict]) -> None:
    tmp = path.with_suffix(path.suffix + ".tmp")
    with tmp.open("w", encoding="utf-8", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=RESULT_FIELDS)
        writer.writeheader(); writer.writerows([{k: row.get(k, "") for k in RESULT_FIELDS} for row in rows])
    os.replace(tmp, path)


def read_results(path: Path) -> dict[int, dict]:
    if not path.exists(): return {}
    with path.open(encoding="utf-8-sig", newline="") as stream:
        return {int(row["ID"]): row for row in csv.DictReader(stream)}


def abaqus_version(cfg: dict) -> str:
    try:
        result = subprocess.run(f"{cfg['solver']['abaqus_command']} information=release", shell=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, check=False, timeout=30)
        text = result.stdout or ""
        match = re.search(r"Abaqus\s+(20\d{2})", text, re.IGNORECASE)
        return match.group(0) if match else (text.strip().splitlines()[-1][:200] or "unknown")
    except Exception:
        return "unknown"


def fingerprint(cfg: dict, samples_path: Path, inp_path: Path, version: str) -> dict:
    hashes = {"config_sha256": sha256_file(CONFIG_PATH), "sample_generator_sha256": sha256_file(SAMPLE_GENERATOR), "pipeline_sha256": sha256_file(Path(__file__)), "extractor_sha256": sha256_file(EXTRACT_SCRIPT), "samples_sha256": sha256_file(samples_path), "inp_sha256": sha256_file(inp_path)}
    model = {"model_version": MODEL_VERSION, "abaqus_version": version, "geometry": cfg["geometry"], "material": cfg["material"], "mesh": cfg["mesh"], "boundary": cfg["boundary"], "load": cfg["load"], "hashes": hashes}
    hashes["model_fingerprint"] = hashlib.sha256(json.dumps(model, sort_keys=True).encode()).hexdigest()
    return {**hashes, "abaqus_version": version, "model_version": MODEL_VERSION}


def representative_ids(samples: list[Sample]) -> list[int]:
    def pick(key, reverse=False): return sorted(samples, key=lambda s: (key(s), -s.sample_id if reverse else s.sample_id), reverse=reverse)[0].sample_id
    ids = [0, pick(lambda s: (s.wave_count, s.amplitude), True), pick(lambda s: s.amplitude), pick(lambda s: abs(s.wave_count - 12) + s.amplitude), pick(lambda s: s.tmin, True), pick(lambda s: s.tavg), pick(lambda s: s.tmax, True), pick(lambda s: (-s.wave_count, s.amplitude), True)]
    # Keep the review-requested ID=209 checkpoint even when another criterion
    # selects the same row, so the pilot always contains eight official IDs.
    if 209 not in ids:
        ids.insert(3, 209)
    return list(dict.fromkeys(ids))[:8]


def result_base(sample: Sample, diag: dict, support: dict, fp: dict) -> dict:
    result = {"ID": sample.sample_id, "tmin_mm": sample.tmin, "N": sample.wave_count, "s_amplitude_mm": sample.amplitude, "mass_kg": "", "status": "FAILED", "failure_type": "", "failure_message": "", "warning_message": "", "stress_status": "DEFERRED", **fp, **diag, **support, "odb_opened": ""}
    return result


def process(sample: Sample, cfg: dict, paths: dict[str, Path], samples_path: Path, existing: dict[int, dict], retry_failed: bool, generate_only: bool, version: str) -> dict:
    mesh = build_model_mesh(sample, cfg)
    diag, support = mesh_diagnostics(sample, mesh), support_metadata(mesh)
    inp = paths["inp"] / f"sample_{sample.sample_id:03d}.inp"
    write_inp(sample, mesh, cfg, inp)
    fp = fingerprint(cfg, samples_path, inp, version)
    base = result_base(sample, diag, support, fp)
    old = existing.get(sample.sample_id)
    if not generate_only and old and old.get("status") == "SUCCESS" and all(old.get(k) == str(fp.get(k, "")) for k in fp) and old.get("ID") == str(sample.sample_id) and old.get("eigenvalue_3", "") and (paths["odb"] / f"sample_{sample.sample_id:03d}.odb").exists() and not retry_failed:
        log(paths, f"Resume skip sample {sample.sample_id:03d} | fingerprint and artifacts match", sample.sample_id)
        return old
    if generate_only:
        base["status"] = "GENERATED"
        return base
    work = paths["work"] / f"attempt_{sample.sample_id:03d}_{int(time.time())}"
    work.mkdir(parents=True, exist_ok=True)
    job = f"sample_{sample.sample_id:03d}_v2_1_{int(time.time())}"
    local_inp = work / f"{job}.inp"
    local_inp.write_bytes(inp.read_bytes())
    ok, output = run_abaqus(job, local_inp, work, cfg)
    (paths["logs"] / f"sample_{sample.sample_id:03d}_solver.log").write_text(output, encoding="utf-8", errors="ignore")
    dat = work / f"{job}.dat"
    raw = parse_eigenvalues(dat)
    chosen = valid_eigenvalues(raw, float(cfg["solver"]["min_physical_eigenvalue"]))
    odb_local = work / f"{job}.odb"
    odb_out = paths["odb"] / f"sample_{sample.sample_id:03d}.odb"
    if odb_local.exists():
        import shutil; shutil.copy2(odb_local, odb_out)
    artifact_ok, reason = artifact_check(job, work, odb_local, raw, cfg) if ok else (False, "Abaqus subprocess failed")
    base["raw_eigenvalues"] = json.dumps(raw)
    for i, value in enumerate(chosen, 1): base[f"eigenvalue_{i}"] = value
    base["mass_kg"] = legacy.shell_mass_exact_kg(sample, cfg) + 2.0 * math.pi * (sample.endplate_diameter / 2.0) ** 2 * sample.endplate_thickness * float(cfg["material"]["density_tonne_per_mm3"]) * 1000.0
    base["status"] = "SUCCESS" if artifact_ok else "FAILED"
    if not artifact_ok:
        base["failure_type"] = "SOLVER_OR_VALIDATION"
        base["failure_message"] = reason
    else:
        base["warning_message"] = "Stress extraction DEFERRED; thickness warnings are non-fatal only."
    odb_metrics = work / "odb_metrics_v2_1.json"
    extractor_ok = False
    if artifact_ok:
        command = f"{cfg['solver']['abaqus_command']} python \"{EXTRACT_SCRIPT}\" --odb \"{odb_local}\" --output \"{odb_metrics}\""
        extracted = subprocess.run(command, cwd=str(work), shell=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, check=False)
        (paths["logs"] / f"sample_{sample.sample_id:03d}_odb.log").write_text(extracted.stdout or "", encoding="utf-8", errors="ignore")
        if odb_metrics.exists():
            try:
                payload = json.loads(odb_metrics.read_text(encoding="utf-8"))
                extractor_ok = bool(payload.get("odb_opened"))
                if payload.get("warning_message"):
                    base["warning_message"] = payload["warning_message"]
            except (OSError, ValueError):
                extractor_ok = False
    base["odb_opened"] = "TRUE" if extractor_ok else "FALSE"
    if base["status"] == "SUCCESS" and not extractor_ok:
        base["status"] = "FAILED"
        base["failure_type"] = "ODB_VALIDATION"
        base["failure_message"] = "ODB did not pass the Abaqus odbAccess open check"
    log(paths, f"Finish sample {sample.sample_id:03d} | eig={base.get('eigenvalue_1','')} | status={base['status']} | reason={reason}", sample.sample_id)
    return base


def parse_ids(text: str) -> list[int]:
    return [int(x.strip()) for x in text.split(",") if x.strip()]


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--sample-ids")
    parser.add_argument("--pilot", action="store_true")
    parser.add_argument("--all", action="store_true")
    parser.add_argument("--generate-only", action="store_true")
    parser.add_argument("--retry-failed", action="store_true")
    parser.add_argument("--with-static-stress", action="store_true", help="rejected: stress is intentionally deferred in v2_1")
    args = parser.parse_args()
    if args.with_static_stress:
        parser.error("v2_1 intentionally keeps stress extraction DEFERRED; no static stress job is implemented")
    cfg = load_config(); paths = output_paths(cfg); ensure_dirs(paths)
    if not paths["samples"].exists():
        subprocess.check_call([sys.executable, str(SAMPLE_GENERATOR)])
    samples = read_samples(paths["samples"]); validate_samples(samples, cfg)
    ids = list(range(len(samples))) if args.all else (parse_ids(args.sample_ids) if args.sample_ids else representative_ids(samples) if args.pilot else [0])
    if args.pilot:
        log(paths, f"Automatically selected representative IDs: {ids}")
    existing = read_results(paths["results"])
    version = abaqus_version(cfg)
    if not paths["results"].exists(): atomic_csv(paths["results"], [])
    rows = existing.copy()
    for sample_id in ids:
        if not 0 <= sample_id < len(samples): raise ValueError(f"invalid sample ID {sample_id}")
        rows[sample_id] = process(samples[sample_id], cfg, paths, paths["samples"], rows, args.retry_failed, args.generate_only, version)
        atomic_csv(paths["results"], [rows[k] for k in sorted(rows)])
    log(paths, f"Completed requested IDs: {ids}")


if __name__ == "__main__":
    main()
