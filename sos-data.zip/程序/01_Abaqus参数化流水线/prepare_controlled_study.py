from __future__ import annotations

import csv
import json
import random
from pathlib import Path


ROOT = Path(__file__).resolve().parent
CONFIG = ROOT / "config_v2_1.json"
OUTPUT_ROOT = ROOT / "parametric_v2_1_outputs"
SAMPLES = OUTPUT_ROOT / "samples_v2_1.csv"


def row(sample_id: int, tmin: float, amplitude: float, n: int, cfg: dict) -> dict:
    return {
        "ID": sample_id,
        "tmin_mm": round(tmin, 5),
        "N": int(n),
        "s_amplitude_mm": round(amplitude, 5),
        "total_corrugation_height_mm": round(2.0 * amplitude, 5),
        "tavg_mm": round(tmin + amplitude, 5),
        "tmax_mm": round(tmin + 2.0 * amplitude, 5),
        "D_mm": cfg["geometry"]["D_mm"],
        "L_mm": cfg["geometry"]["L_mm"],
        "endplate_diameter_mm": cfg["geometry"]["endplate_diameter_mm"],
        "endplate_thickness_mm": cfg["geometry"]["endplate_thickness_mm"],
        "random_seed": cfg["random_seed"],
        "sample_version": "concept_controlled_equal_tavg_v1",
    }


def make_controlled(cfg: dict) -> list[dict]:
    # The first 27 rows are a controlled study.  Each tavg family keeps
    # tmin + amplitude constant while N is varied at 3, 5, and 7.
    families = {
        2.0: [(1.0, 1.0), (1.5, 0.5)],
        2.5: [(1.0, 1.5), (1.5, 1.0), (2.0, 0.5)],
        3.0: [(1.0, 2.0), (1.5, 1.5), (2.0, 1.0), (2.5, 0.5)],
    }
    rows: list[dict] = [row(0, 1.0, 1.0, 5, cfg)]
    sample_id = 1
    for tavg in (2.0, 2.5, 3.0):
        for tmin, amplitude in families[tavg]:
            for n in (3, 5, 7):
                if (tmin, amplitude, n) == (1.0, 1.0, 5):
                    continue
                rows.append(row(sample_id, tmin, amplitude, n, cfg))
                sample_id += 1

    # The remaining rows are reproducible seeded uniform random draws.
    # They are not a Latin hypercube design.
    rng = random.Random(cfg["random_seed"])
    while len(rows) < int(cfg["num_samples"]):
        tmin = 1.0 + 3.0 * rng.random()
        amplitude = 0.5 + 2.5 * rng.random()
        n = rng.randint(3, 15)
        rows.append(row(len(rows), tmin, amplitude, n, cfg))
    return rows


def main() -> None:
    cfg = json.loads(CONFIG.read_text(encoding="utf-8"))
    OUTPUT_ROOT.mkdir(parents=True, exist_ok=True)
    rows = make_controlled(cfg)
    with SAMPLES.open("w", encoding="utf-8-sig", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
    print(f"wrote {len(rows)} rows to {SAMPLES}")
    for r in rows[:27]:
        print(r["ID"], r["tmin_mm"], r["s_amplitude_mm"], r["N"], r["tavg_mm"])


if __name__ == "__main__":
    main()
