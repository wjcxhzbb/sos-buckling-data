"""Versioned linear buckling pipeline for the 150 x 200 mm v2 study.

The legacy pipeline is intentionally not imported. This module uses absolute
paths rooted at its own directory and writes only into parametric_v2_outputs.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import re
import shutil
import subprocess
import time
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Sequence, Tuple


ROOT = Path(__file__).resolve().parent
CONFIG_PATH = ROOT / "config_v2.json"
EXTRACT_SCRIPT = ROOT / "extract_odb_v2.py"
DECIMALS = 5
MODEL_VERSION = "parametric_v2_zero_phase"


@dataclass(frozen=True)
class Sample:
    sample_id: int
    tmin: float
    wave_count: int
    amplitude: float
    diameter: float
    length: float
    endplate_diameter: float
    endplate_thickness: float

    @property
    def rout(self) -> float:
        return self.diameter / 2.0

    @property
    def tavg(self) -> float:
        return self.tmin + self.amplitude

    @property
    def tmax(self) -> float:
        return self.tmin + 2.0 * self.amplitude

    @property
    def total_corrugation_height(self) -> float:
        return 2.0 * self.amplitude


def load_config() -> dict:
    with CONFIG_PATH.open("r", encoding="utf-8") as stream:
        return json.load(stream)


def config_sha256() -> str:
    return hashlib.sha256(CONFIG_PATH.read_bytes()).hexdigest()


def output_paths(config: dict) -> Dict[str, Path]:
    root = ROOT / config["outputs"]["root"]
    return {
        "root": root,
        "samples": root / config["outputs"]["samples_csv"],
        "results": root / config["outputs"]["results_csv"],
        "logs": root / config["outputs"]["logs_dir"],
        "work": root / config["outputs"]["work_dir"],
        "inp": root / config["outputs"]["inp_dir"],
        "odb": root / config["outputs"]["odb_dir"],
        "pilot_report": root / config["outputs"]["pilot_report"],
    }


def ensure_output_dirs(paths: Dict[str, Path]) -> None:
    for key in ("root", "logs", "work", "inp", "odb"):
        paths[key].mkdir(parents=True, exist_ok=True)


def now_iso() -> str:
    return datetime.now().astimezone().isoformat(timespec="seconds")


def log_master(paths: Dict[str, Path], message: str) -> None:
    line = f"[{time.strftime('%Y-%m-%d %H:%M:%S')}] {message}"
    print(line)
    with (paths["root"] / "pipeline_v2.log").open("a", encoding="utf-8") as stream:
        stream.write(line + "\n")


def log_sample(paths: Dict[str, Path], sample_id: int, message: str) -> None:
    path = paths["logs"] / f"sample_{sample_id:03d}.log"
    with path.open("a", encoding="utf-8") as stream:
        stream.write(f"[{time.strftime('%Y-%m-%d %H:%M:%S')}] {message}\n")


def read_samples(path: Path) -> List[Sample]:
    if not path.exists():
        raise FileNotFoundError(f"v2 sample table not found: {path}")
    samples = []
    with path.open("r", newline="", encoding="utf-8") as stream:
        for row in csv.DictReader(stream):
            samples.append(
                Sample(
                    sample_id=int(row["ID"]),
                    tmin=float(row["tmin_mm"]),
                    wave_count=int(row["N"]),
                    amplitude=float(row["s_amplitude_mm"]),
                    diameter=float(row["D_mm"]),
                    length=float(row["L_mm"]),
                    endplate_diameter=float(row["endplate_diameter_mm"]),
                    endplate_thickness=float(row["endplate_thickness_mm"]),
                )
            )
    return samples


def validate_sample_table(samples: Sequence[Sample], config: dict) -> None:
    if len(samples) != int(config["num_samples"]):
        raise ValueError(f"expected 600 samples, got {len(samples)}")
    ids = [sample.sample_id for sample in samples]
    if ids != list(range(600)):
        raise ValueError("sample IDs must be exactly 0..599 in order")
    first = samples[0]
    if (first.tmin, first.wave_count, first.amplitude) != (1.0, 5, 1.0):
        raise ValueError("ID=0 is not the required Corrugate 1-5-2.0 baseline")
    tmin_lo, tmin_hi = config["design_ranges"]["tmin_mm"]
    amp_lo, amp_hi = config["design_ranges"]["s_amplitude_mm"]
    n_lo, n_hi = config["design_ranges"]["N"]
    for sample in samples:
        if not (float(tmin_lo) <= sample.tmin <= float(tmin_hi)):
            raise ValueError(f"tmin outside range at ID={sample.sample_id}")
        if not (float(amp_lo) <= sample.amplitude <= float(amp_hi)):
            raise ValueError(f"s outside range at ID={sample.sample_id}")
        if not (int(n_lo) <= sample.wave_count <= int(n_hi)):
            raise ValueError(f"N outside range at ID={sample.sample_id}")
        if sample.tmax >= sample.rout:
            raise ValueError(f"inner radius is not positive at ID={sample.sample_id}")


def t_of_z(sample: Sample, z: float) -> float:
    # Zero phase: both ends have average thickness tmin+s.
    return sample.tmin + sample.amplitude + sample.amplitude * math.sin(
        2.0 * math.pi * sample.wave_count * z / sample.length
    )


def r_in(sample: Sample, z: float) -> float:
    return sample.rout - t_of_z(sample, z)


def round_even(value: int) -> int:
    value = int(value)
    return value if value % 2 == 0 else value + 1


def choose_mesh_counts(sample: Sample, config: dict) -> Tuple[int, int]:
    mesh_cfg = config["mesh"]
    target = float(mesh_cfg["target_surface_edge_mm"])
    mean_radius = sample.rout - 0.5 * sample.tavg
    n_circ = round_even(int(round(2.0 * math.pi * mean_radius / target)))
    n_circ = max(int(mesh_cfg["min_circumferential_divisions"]), n_circ)
    n_circ = min(int(mesh_cfg["max_circumferential_divisions"]), n_circ)
    target_axial = max(target, 2.0 * math.pi * mean_radius / n_circ)
    n_axial = int(math.ceil(sample.length / target_axial))
    per_wave = int(mesh_cfg["axial_elements_per_wave"])
    n_axial = max(n_axial, per_wave * sample.wave_count)
    n_axial = int(math.ceil(n_axial / (per_wave * sample.wave_count)) * per_wave * sample.wave_count)
    return n_axial, n_circ


def square_to_disk(u: float, v: float, radius: float) -> Tuple[float, float]:
    """Concentric square-to-disk map; all quad boundary nodes lie on the circle."""
    if abs(u) < 1e-14 and abs(v) < 1e-14:
        return 0.0, 0.0
    if abs(u) > abs(v):
        radial = u
        phi = math.pi * v / (4.0 * u)
    else:
        radial = v
        phi = math.pi / 2.0 - math.pi * u / (4.0 * v)
    return radius * radial * math.cos(phi), radius * radial * math.sin(phi)


def build_plate_mesh(start_node: int, start_element: int, radius: float, grid_divisions: int, z: float) -> dict:
    nodes = []
    node_map = {}
    node_id = start_node
    half = grid_divisions / 2.0
    for j in range(grid_divisions + 1):
        for i in range(grid_divisions + 1):
            u = (i - half) / half
            v = (j - half) / half
            x, y = square_to_disk(u, v, radius)
            node_map[(i, j)] = node_id
            nodes.append((node_id, x, y, z))
            node_id += 1

    elements = []
    element_id = start_element
    for j in range(grid_divisions):
        for i in range(grid_divisions):
            n1 = node_map[(i, j)]
            n2 = node_map[(i + 1, j)]
            n3 = node_map[(i + 1, j + 1)]
            n4 = node_map[(i, j + 1)]
            elements.append((element_id, n1, n2, n3, n4))
            element_id += 1

    def node_at(i: int, j: int) -> int:
        return node_map[(i, j)]

    mid = grid_divisions // 2
    support = {
        "A": node_at(grid_divisions, mid),
        "B": node_at(mid, grid_divisions),
        "C": node_at(0, mid),
    }
    return {
        "nodes": nodes,
        "elements": elements,
        "node_ids": [node[0] for node in nodes],
        "support": support,
    }


def build_model_mesh(sample: Sample, config: dict) -> dict:
    n_axial, n_circ = choose_mesh_counts(sample, config)
    n_thick = int(config["mesh"]["thickness_layers"])
    dtheta = 2.0 * math.pi / n_circ
    nodes = []
    shell_node_map = {}
    next_node = 1
    z_coords = [sample.length * index / n_axial for index in range(n_axial + 1)]

    for i_ax, z in enumerate(z_coords):
        rin = r_in(sample, z)
        thickness = sample.rout - rin
        for i_circ in range(n_circ):
            theta = i_circ * dtheta
            for i_thick in range(n_thick + 1):
                fraction = i_thick / float(n_thick)
                radius = rin + fraction * thickness
                node_id = next_node
                shell_node_map[(i_ax, i_circ, i_thick)] = node_id
                nodes.append((node_id, radius * math.cos(theta), radius * math.sin(theta), z))
                next_node += 1

    solid_elements = []
    shell_outer_face_elements = []
    shell_left_face_elements = []
    shell_right_face_elements = []
    shell_element_volumes = []
    next_element = 1
    for i_ax in range(n_axial):
        z0 = z_coords[i_ax]
        z1 = z_coords[i_ax + 1]
        dz = z1 - z0
        rin0 = r_in(sample, z0)
        rin1 = r_in(sample, z1)
        t0 = sample.rout - rin0
        t1 = sample.rout - rin1
        for i_circ in range(n_circ):
            i_circ2 = (i_circ + 1) % n_circ
            for i_thick in range(n_thick):
                n1 = shell_node_map[(i_ax, i_circ, i_thick)]
                n2 = shell_node_map[(i_ax, i_circ2, i_thick)]
                n3 = shell_node_map[(i_ax + 1, i_circ2, i_thick)]
                n4 = shell_node_map[(i_ax + 1, i_circ, i_thick)]
                n5 = shell_node_map[(i_ax, i_circ, i_thick + 1)]
                n6 = shell_node_map[(i_ax, i_circ2, i_thick + 1)]
                n7 = shell_node_map[(i_ax + 1, i_circ2, i_thick + 1)]
                n8 = shell_node_map[(i_ax + 1, i_circ, i_thick + 1)]
                solid_elements.append((next_element, n1, n2, n3, n4, n5, n6, n7, n8))
                if i_thick == n_thick - 1:
                    shell_outer_face_elements.append(next_element)
                if i_ax == 0:
                    shell_left_face_elements.append(next_element)
                if i_ax == n_axial - 1:
                    shell_right_face_elements.append(next_element)

                low0 = rin0 + (i_thick / float(n_thick)) * t0
                low1 = rin1 + (i_thick / float(n_thick)) * t1
                high0 = rin0 + ((i_thick + 1) / float(n_thick)) * t0
                high1 = rin1 + ((i_thick + 1) / float(n_thick)) * t1
                low_integral = low0 * low0 + low0 * low1 + low1 * low1
                high_integral = high0 * high0 + high0 * high1 + high1 * high1
                shell_element_volumes.append(0.5 * dtheta * dz * (high_integral - low_integral) / 3.0)
                next_element += 1

    shell_node_ids = [node[0] for node in nodes]
    shell_element_ids = [element[0] for element in solid_elements]
    grid = int(config["mesh"]["endplate_grid_divisions"])
    plate_radius = sample.endplate_diameter / 2.0
    # Place the S4R reference planes outside the cylinder so their physical
    # inner surfaces coincide with the solid shell end faces: z=-t/2 and
    # z=L+t/2 for a +Z shell normal.
    left_z = -0.5 * sample.endplate_thickness
    right_z = sample.length + 0.5 * sample.endplate_thickness
    left = build_plate_mesh(next_node, next_element, plate_radius, grid, left_z)
    next_node = max(node[0] for node in left["nodes"]) + 1
    next_element = max(element[0] for element in left["elements"]) + 1
    right = build_plate_mesh(next_node, next_element, plate_radius, grid, right_z)
    nodes.extend(left["nodes"])
    nodes.extend(right["nodes"])
    plate_elements = left["elements"] + right["elements"]
    plate_node_ids = left["node_ids"] + right["node_ids"]
    plate_element_ids = [element[0] for element in plate_elements]

    left_node_ids = left["node_ids"]
    right_node_ids = right["node_ids"]
    return {
        "nodes": nodes,
        "solid_elements": solid_elements,
        "plate_elements": plate_elements,
        "left_plate_elements": [element[0] for element in left["elements"]],
        "right_plate_elements": [element[0] for element in right["elements"]],
        "shell_element_ids": shell_element_ids,
        "plate_element_ids": plate_element_ids,
        "shell_node_ids": shell_node_ids,
        "plate_node_ids": plate_node_ids,
        "left_plate_node_ids": left_node_ids,
        "right_plate_node_ids": right_node_ids,
        "shell_outer_face_elements": shell_outer_face_elements,
        "shell_left_face_elements": shell_left_face_elements,
        "shell_right_face_elements": shell_right_face_elements,
        "support": left["support"],
        "n_axial": n_axial,
        "n_circ": n_circ,
        "n_thick": n_thick,
        "shell_element_volumes": shell_element_volumes,
        "plate_grid_divisions": grid,
    }


def write_id_block(stream, values: Iterable[int], per_line: int = 16) -> None:
    values = list(values)
    for start in range(0, len(values), per_line):
        stream.write(", ".join(str(value) for value in values[start : start + per_line]) + "\n")


def write_element_set(stream, name: str, values: Iterable[int], instance: Optional[str] = None) -> None:
    suffix = f", instance={instance}" if instance else ""
    stream.write(f"*Elset, elset={name}{suffix}\n")
    write_id_block(stream, values)


def write_node_set(stream, name: str, values: Iterable[int], instance: Optional[str] = None) -> None:
    suffix = f", instance={instance}" if instance else ""
    stream.write(f"*Nset, nset={name}{suffix}\n")
    write_id_block(stream, values)


def write_inp(sample: Sample, mesh: dict, config: dict, out_path: Path) -> None:
    material = config["material"]
    load = config["load"]
    solver = config["solver"]
    rp_left = max(node[0] for node in mesh["nodes"]) + 1

    with out_path.open("w", encoding="utf-8", newline="\n") as stream:
        stream.write("*Heading\n")
        stream.write(f"** v2 sample {sample.sample_id}: zero-phase inner corrugated shell\n")
        stream.write(f"** t(z)=tmin+s+s*sin(2*pi*N*z/L), thickness layers={mesh['n_thick']}\n")
        stream.write(f"** Configuration SHA256: {config_sha256()}\n")
        stream.write("*Preprint, echo=NO, model=NO, history=NO, contact=NO\n")
        stream.write("*Part, name=MODEL\n")
        stream.write("*Node\n")
        for node_id, x, y, z in mesh["nodes"]:
            stream.write(f"{node_id}, {x:.10f}, {y:.10f}, {z:.10f}\n")
        stream.write("*Element, type=C3D8R\n")
        for element in mesh["solid_elements"]:
            stream.write(f"{element[0]}, {', '.join(str(value) for value in element[1:])}\n")
        stream.write("*Element, type=S4R\n")
        for element in mesh["plate_elements"]:
            stream.write(f"{element[0]}, {', '.join(str(value) for value in element[1:])}\n")

        write_node_set(stream, "SHELL_NODES", mesh["shell_node_ids"])
        write_node_set(stream, "PLATE_NODES", mesh["plate_node_ids"])
        write_node_set(stream, "SUPPORT_A", [mesh["support"]["A"]])
        write_node_set(stream, "SUPPORT_B", [mesh["support"]["B"]])
        write_node_set(stream, "SUPPORT_C", [mesh["support"]["C"]])
        write_element_set(stream, "SHELL_ELEMS", mesh["shell_element_ids"])
        write_element_set(stream, "PLATE_ELEMS", mesh["plate_element_ids"])
        write_element_set(stream, "PLATE_LEFT_ELEMS", mesh["left_plate_elements"])
        write_element_set(stream, "PLATE_RIGHT_ELEMS", mesh["right_plate_elements"])
        material_name = material["name"]
        stream.write(f"*Solid Section, elset=SHELL_ELEMS, material={material_name}\n,\n")
        stream.write(f"*Shell Section, elset=PLATE_ELEMS, material={material_name}\n")
        stream.write(f"{sample.endplate_thickness:.10f},\n")
        stream.write("*End Part\n")

        stream.write(f"*Material, name={material['name']}\n")
        stream.write("*Density\n")
        stream.write(f"{float(material['density_tonne_per_mm3']):.12g}\n")
        stream.write("*Elastic\n")
        stream.write(f"{float(material['E_MPa']):.10f}, {float(material['nu']):.10f}\n")

        stream.write("*Assembly, name=ASSEMBLY\n")
        stream.write("*Instance, name=MODEL_INST, part=MODEL\n*End Instance\n")
        write_node_set(stream, "SUPPORT_A_INST", [mesh["support"]["A"]], "MODEL_INST")
        write_node_set(stream, "SUPPORT_B_INST", [mesh["support"]["B"]], "MODEL_INST")
        write_node_set(stream, "SUPPORT_C_INST", [mesh["support"]["C"]], "MODEL_INST")
        write_node_set(stream, "SHELL_NODES_INST", mesh["shell_node_ids"], "MODEL_INST")
        write_node_set(stream, "PLATE_NODES_INST", mesh["plate_node_ids"], "MODEL_INST")
        write_element_set(stream, "SHELL_ELEMS_INST", mesh["shell_element_ids"], "MODEL_INST")
        write_element_set(stream, "PLATE_ELEMS_INST", mesh["plate_element_ids"], "MODEL_INST")
        write_element_set(stream, "SHELL_OUTER_FACE_ELEMS", mesh["shell_outer_face_elements"], "MODEL_INST")
        write_element_set(stream, "SHELL_LEFT_FACE_ELEMS", mesh["shell_left_face_elements"], "MODEL_INST")
        write_element_set(stream, "SHELL_RIGHT_FACE_ELEMS", mesh["shell_right_face_elements"], "MODEL_INST")
        write_element_set(stream, "PLATE_LEFT_ELEMS_INST", mesh["left_plate_elements"], "MODEL_INST")
        write_element_set(stream, "PLATE_RIGHT_ELEMS_INST", mesh["right_plate_elements"], "MODEL_INST")

        stream.write("*Surface, type=ELEMENT, name=SHELL_OUTER\nSHELL_OUTER_FACE_ELEMS, S2\n")
        stream.write("*Surface, type=ELEMENT, name=SHELL_LEFT_TIE\nSHELL_LEFT_FACE_ELEMS, S3\n")
        stream.write("*Surface, type=ELEMENT, name=SHELL_RIGHT_TIE\nSHELL_RIGHT_FACE_ELEMS, S5\n")
        stream.write("*Surface, type=ELEMENT, name=PLATE_LEFT_INNER\nPLATE_LEFT_ELEMS_INST, SPOS\n")
        stream.write("*Surface, type=ELEMENT, name=PLATE_RIGHT_INNER\nPLATE_RIGHT_ELEMS_INST, SNEG\n")
        stream.write("*Surface, type=ELEMENT, name=PLATE_LEFT_OUTER\nPLATE_LEFT_ELEMS_INST, SNEG\n")
        stream.write("*Surface, type=ELEMENT, name=PLATE_RIGHT_OUTER\nPLATE_RIGHT_ELEMS_INST, SPOS\n")
        # Abaqus reads the first surface as secondary and the second as main.
        # Keep the shell end ring secondary and the full plate inner face main
        # so only shell-end nodes are projected onto the plate disk.
        stream.write("*Tie, name=TIE_LEFT, position tolerance=0.25\nSHELL_LEFT_TIE, PLATE_LEFT_INNER\n")
        stream.write("*Tie, name=TIE_RIGHT, position tolerance=0.25\nSHELL_RIGHT_TIE, PLATE_RIGHT_INNER\n")
        stream.write("*End Assembly\n")

        stream.write("** Engineering reconstruction of the paper's three-point support: 3-2-1 translational constraints.\n")
        stream.write("*Boundary\n")
        stream.write("SUPPORT_A_INST, 1, 3, 0.0\n")
        stream.write("SUPPORT_B_INST, 2, 3, 0.0\n")
        stream.write("SUPPORT_C_INST, 3, 3, 0.0\n")
        stream.write("*Step, name=BUCKLE, nlgeom=NO, perturbation\n")
        stream.write("*Buckle, eigensolver=Subspace\n")
        stream.write(
            f"{int(solver['buckle_modes'])}, , {int(solver['buckle_vectors'])}, {int(solver['buckle_max_iterations'])}\n"
        )
        stream.write("*Dsload\n")
        pressure = float(load["reference_pressure_MPa"])
        stream.write(f"SHELL_OUTER, P, {pressure:.10f}\n")
        stream.write(f"PLATE_LEFT_OUTER, P, {pressure:.10f}\n")
        stream.write(f"PLATE_RIGHT_OUTER, P, {pressure:.10f}\n")
        # Stress fields are not guaranteed in a linear perturbation BUCKLE
        # output for these element types; ODB extraction leaves them blank.
        stream.write("*Output, field\n*Node Output\nU\n")
        stream.write("*End Step\n")


def shell_mass_exact_kg(sample: Sample, config: dict) -> float:
    density = float(config["material"]["density_tonne_per_mm3"])
    volume = math.pi * sample.length * (
        2.0 * sample.rout * sample.tavg - sample.tavg * sample.tavg - sample.amplitude * sample.amplitude / 2.0
    )
    return volume * density * 1000.0


def plate_area_from_elements(mesh: dict, element_ids: set) -> float:
    coords = {node[0]: (node[1], node[2]) for node in mesh["nodes"]}
    total = 0.0
    for element in mesh["plate_elements"]:
        if element[0] not in element_ids:
            continue
        points = [coords[node_id] for node_id in element[1:]]
        total += 0.5 * abs(
            sum(points[i][0] * points[(i + 1) % 4][1] - points[(i + 1) % 4][0] * points[i][1] for i in range(4))
        )
    return total


def mass_metrics(sample: Sample, mesh: dict, config: dict) -> dict:
    density = float(config["material"]["density_tonne_per_mm3"])
    shell_volume_fe = sum(mesh["shell_element_volumes"])
    plate_area_fe = plate_area_from_elements(mesh, set(mesh["plate_element_ids"]))
    plate_volume_fe = plate_area_fe * sample.endplate_thickness
    shell_exact = shell_mass_exact_kg(sample, config)
    shell_fe = shell_volume_fe * density * 1000.0
    plates_exact = 2.0 * math.pi * (sample.endplate_diameter / 2.0) ** 2 * sample.endplate_thickness * density * 1000.0
    plates_fe = plate_volume_fe * density * 1000.0
    return {
        "shell_mass_exact_kg": shell_exact,
        "shell_mass_fe_kg": shell_fe,
        "shell_mass_relative_error": (shell_fe - shell_exact) / shell_exact if shell_exact else None,
        "endplates_mass_kg": plates_exact,
        "endplates_mass_fe_kg": plates_fe,
        "total_model_mass_kg": shell_fe + plates_fe,
        "shell_volume_exact_mm3": shell_exact / (density * 1000.0),
        "shell_volume_fe_mm3": shell_volume_fe,
        # plate_area_fe already includes both left and right endplates.
        "endplates_area_fe_mm2": plate_area_fe,
    }


def support_metadata(sample: Sample, mesh: dict) -> dict:
    node_by_id = {node[0]: node for node in mesh["nodes"]}
    constraints = {"A": "U1,U2,U3", "B": "U2,U3", "C": "U3"}
    result = {}
    for name in ("A", "B", "C"):
        node_id = mesh["support"][name]
        node = node_by_id[node_id]
        result[f"support_{name}_node"] = node_id
        result[f"support_{name}_xyz"] = ";".join(f"{value:.6f}" for value in node[1:])
        result[f"support_{name}_dofs"] = constraints[name]
    return result


def mesh_diagnostics(sample: Sample, mesh: dict) -> dict:
    mean_radius = sample.rout - 0.5 * sample.tavg
    circum_edge = 2.0 * math.pi * mean_radius / mesh["n_circ"]
    axial_edge = sample.length / mesh["n_axial"]
    thickness_edge = min(sample.tmin, sample.tmax) / mesh["n_thick"]
    return {
        "n_axial": mesh["n_axial"],
        "n_circumferential": mesh["n_circ"],
        "thickness_layers": mesh["n_thick"],
        "nodes": len(mesh["nodes"]),
        "elements": len(mesh["solid_elements"]) + len(mesh["plate_elements"]),
        "shell_elements": len(mesh["solid_elements"]),
        "endplate_elements": len(mesh["plate_elements"]),
        "shell_surface_edge_mm": circum_edge,
        "axial_edge_mm": axial_edge,
        "minimum_radial_element_edge_mm": thickness_edge,
        "mesh_aspect_warning": "" if max(circum_edge, axial_edge) / max(thickness_edge, 1e-12) < 20.0 else "high thickness-direction aspect ratio; no convergence claim",
    }


def parse_eigenvalues(dat_path: Path) -> List[float]:
    if not dat_path.exists():
        return []
    lines = dat_path.read_text(encoding="utf-8", errors="ignore").splitlines()
    values = []
    in_table = False
    number = r"[+-]?(?:\d+(?:\.\d*)?|\.\d+)(?:[Ee][+-]?\d+)?"
    for line in lines:
        upper = line.upper()
        if "MODE" in upper and "EIGENVALUE" in upper:
            in_table = True
            continue
        if not in_table:
            continue
        match = re.match(rf"^\s*(\d+)\s+({number})", line)
        if match:
            values.append(float(match.group(2)))
            continue
        if values and not line.strip():
            break
        if values and "EIGENVALUE" not in upper:
            break
    return values


def run_abaqus(job_name: str, inp_path: Path, work_dir: Path, config: dict) -> Tuple[bool, str]:
    command = str(config["solver"]["abaqus_command"])
    command_line = f"{command} job={job_name} input={inp_path.name} interactive"
    try:
        completed = subprocess.run(
            command_line,
            cwd=str(work_dir),
            shell=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            check=False,
        )
        output = completed.stdout or ""
        upper = output.upper()
        error_marker = "EXITS WITH AN ERROR" in upper or "ABAQUS ERROR:" in upper or "EXITED WITH ERROR" in upper
        return completed.returncode == 0 and not error_marker, output
    except Exception as exc:
        return False, str(exc)


def optional_odb_metrics(odb_path: Path, work_dir: Path, config: dict, log_path: Path) -> dict:
    output_path = work_dir / "odb_metrics_v2.json"
    command = str(config["solver"]["abaqus_command"])
    command_line = f"{command} python \"{EXTRACT_SCRIPT}\" --odb \"{odb_path}\" --output \"{output_path}\""
    try:
        completed = subprocess.run(
            command_line,
            cwd=str(work_dir),
            shell=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            check=False,
        )
        log_path.write_text(completed.stdout or "", encoding="utf-8")
        if output_path.exists():
            with output_path.open("r", encoding="utf-8") as stream:
                return json.load(stream)
        return {"status": "FAILED", "warning": "ODB extraction did not create a JSON result"}
    except Exception as exc:
        return {"status": "FAILED", "warning": str(exc)}


RESULT_FIELDS = [
    "ID", "D_mm", "L_mm", "tmin_mm", "N", "s_amplitude_mm", "total_corrugation_height_mm", "tavg_mm", "tmax_mm",
    "endplate_diameter_mm", "endplate_thickness_mm", "shell_mass_exact_kg", "shell_mass_fe_kg",
    "shell_mass_relative_error", "endplates_mass_kg", "endplates_mass_fe_kg", "total_model_mass_kg",
    "eigenvalue_1", "eigenvalue_2", "eigenvalue_3", "linear_buckling_pressure_1_MPa",
    "linear_buckling_pressure_2_MPa", "linear_buckling_pressure_3_MPa", "shell_max_mises_1MPa",
    "endplate_max_mises_1MPa", "mode1_umax_shell", "mode1_umax_endplates", "mode1_plate_shell_ratio",
    "n_axial", "n_circumferential", "thickness_layers", "nodes", "elements", "shell_elements",
    "endplate_elements", "shell_surface_edge_mm", "axial_edge_mm", "minimum_radial_element_edge_mm",
    "mesh_aspect_warning", "support_A_node", "support_A_xyz", "support_A_dofs", "support_B_node",
    "support_B_xyz", "support_B_dofs", "support_C_node", "support_C_xyz", "support_C_dofs", "status",
    "failure_type", "failure_message", "warning_message", "job_directory", "model_version", "config_sha256",
    "start_time", "end_time",
]


def init_results(path: Path) -> None:
    if path.exists():
        return
    with path.open("w", newline="", encoding="utf-8") as stream:
        csv.DictWriter(stream, fieldnames=RESULT_FIELDS).writeheader()


def fmt(value) -> object:
    if value is None:
        return ""
    if isinstance(value, float):
        return f"{value:.{DECIMALS}f}"
    return value


def sample_result_base(sample: Sample, masses: dict, diagnostics: dict, supports: dict, paths: Dict[str, Path], config_hash: str) -> dict:
    result = {
        "ID": sample.sample_id,
        "D_mm": sample.diameter,
        "L_mm": sample.length,
        "tmin_mm": sample.tmin,
        "N": sample.wave_count,
        "s_amplitude_mm": sample.amplitude,
        "total_corrugation_height_mm": sample.total_corrugation_height,
        "tavg_mm": sample.tavg,
        "tmax_mm": sample.tmax,
        "endplate_diameter_mm": sample.endplate_diameter,
        "endplate_thickness_mm": sample.endplate_thickness,
        **masses,
        **diagnostics,
        **supports,
        "job_directory": str(paths["work"] / f"sample_{sample.sample_id:03d}"),
        "model_version": MODEL_VERSION,
        "config_sha256": config_hash,
    }
    return {field: result.get(field, "") for field in RESULT_FIELDS}


def records_by_id(path: Path) -> Dict[int, dict]:
    if not path.exists():
        return {}
    latest = {}
    with path.open("r", newline="", encoding="utf-8") as stream:
        for row in csv.DictReader(stream):
            try:
                latest[int(row["ID"])] = row
            except (KeyError, ValueError):
                continue
    return latest


def can_resume(sample: Sample, row: Optional[dict], config_hash: str, retry_failed: bool) -> bool:
    if not row or row.get("model_version") != MODEL_VERSION or row.get("config_sha256") != config_hash:
        return False
    for key, expected in {
        "D_mm": sample.diameter, "L_mm": sample.length, "tmin_mm": sample.tmin,
        "N": sample.wave_count, "s_amplitude_mm": sample.amplitude,
    }.items():
        try:
            actual = int(row[key]) if key == "N" else float(row[key])
        except (KeyError, TypeError, ValueError):
            return False
        if actual != expected:
            return False
    status = row.get("status", "")
    if status == "FAILED" and retry_failed:
        return False
    if status == "SUCCESS":
        try:
            float(row.get("eigenvalue_1", ""))
        except (TypeError, ValueError):
            return False
        job_dir = Path(row.get("job_directory", ""))
        job_prefix = f"sample_{sample.sample_id:03d}_v2"
        dat_path = job_dir / f"{job_prefix}.dat"
        odb_path = job_dir / f"{job_prefix}.odb"
        if not dat_path.is_file() or not odb_path.is_file():
            return False
        if not parse_eigenvalues(dat_path):
            return False
    elif status == "FAILED":
        if not row.get("failure_type") or not row.get("failure_message"):
            return False
    else:
        return False
    return True


def write_result(path: Path, record: dict) -> None:
    """Replace the latest row for an ID so retries do not create duplicates."""
    new_row = {field: fmt(record.get(field, "")) for field in RESULT_FIELDS}
    rows = []
    if path.exists():
        with path.open("r", newline="", encoding="utf-8") as stream:
            rows = list(csv.DictReader(stream))
    rows = [row for row in rows if row.get("ID") != str(record["ID"])]
    rows.append(new_row)
    rows.sort(key=lambda row: int(row["ID"]))
    with path.open("w", newline="", encoding="utf-8") as stream:
        writer = csv.DictWriter(stream, fieldnames=RESULT_FIELDS)
        writer.writeheader()
        writer.writerows(rows)


def process_sample(sample: Sample, config: dict, paths: Dict[str, Path], config_hash: str, generate_only: bool, retry_failed: bool, existing: Dict[int, dict]) -> None:
    if not generate_only and can_resume(sample, existing.get(sample.sample_id), config_hash, retry_failed):
        log_master(paths, f"Skip sample {sample.sample_id:03d} (validated v2 result already exists)")
        return

    started = now_iso()
    work_dir = paths["work"] / f"sample_{sample.sample_id:03d}"
    work_dir.mkdir(parents=True, exist_ok=True)
    mesh = build_model_mesh(sample, config)
    masses = mass_metrics(sample, mesh, config)
    diagnostics = mesh_diagnostics(sample, mesh)
    supports = support_metadata(sample, mesh)
    inp_path = paths["inp"] / f"sample_{sample.sample_id:03d}.inp"
    write_inp(sample, mesh, config, inp_path)
    base = sample_result_base(sample, masses, diagnostics, supports, paths, config_hash)
    base["start_time"] = started
    base["end_time"] = now_iso()

    log_sample(paths, sample.sample_id, f"INP written: {inp_path}")
    log_sample(paths, sample.sample_id, f"mesh: n_axial={mesh['n_axial']}, n_circ={mesh['n_circ']}, thickness_layers={mesh['n_thick']}")
    log_sample(paths, sample.sample_id, f"supports: {supports}")
    if generate_only:
        log_master(paths, f"Generated sample {sample.sample_id:03d} INP only: {inp_path}")
        return

    # Keep the solver job name separate from legacy/interrupted artifacts in
    # the same sample directory.
    job_name = f"sample_{sample.sample_id:03d}_v2"
    job_inp = work_dir / f"{job_name}.inp"
    shutil.copy2(inp_path, job_inp)
    ok, output = run_abaqus(job_name, job_inp, work_dir, config)
    log_sample(paths, sample.sample_id, output[-5000:])
    base["end_time"] = now_iso()
    if not ok:
        base["status"] = "FAILED"
        base["failure_type"] = "ABAQUS_RUN_FAILED"
        base["failure_message"] = output[-1000:] or "Abaqus returned a failure without console output"
        write_result(paths["results"], base)
        log_master(paths, f"Finish sample {sample.sample_id:03d} | status=FAILED | type=ABAQUS_RUN_FAILED")
        return

    dat_path = work_dir / f"{job_name}.dat"
    eigenvalues = parse_eigenvalues(dat_path)
    for index, value in enumerate(eigenvalues[:3], start=1):
        base[f"eigenvalue_{index}"] = value
        base[f"linear_buckling_pressure_{index}_MPa"] = value * float(config["load"]["reference_pressure_MPa"])
    if not eigenvalues:
        base["status"] = "FAILED"
        base["failure_type"] = "EIGENVALUE_NOT_FOUND"
        base["failure_message"] = "Abaqus completed but no eigenvalue table was parsed from the DAT file"
        write_result(paths["results"], base)
        log_master(paths, f"Finish sample {sample.sample_id:03d} | status=FAILED | type=EIGENVALUE_NOT_FOUND")
        return

    odb_path = work_dir / f"{job_name}.odb"
    if odb_path.exists():
        target_odb = paths["odb"] / f"sample_{sample.sample_id:03d}.odb"
        shutil.copy2(odb_path, target_odb)
        odb_metrics = optional_odb_metrics(odb_path, work_dir, config, paths["logs"] / f"sample_{sample.sample_id:03d}_odb.log")
        for key in ("mode1_umax_shell", "mode1_umax_endplates", "mode1_plate_shell_ratio", "shell_max_mises_1MPa", "endplate_max_mises_1MPa"):
            if odb_metrics.get(key) is not None:
                base[key] = odb_metrics[key]
        if odb_metrics.get("warning"):
            base["warning_message"] = "ODB diagnostic warning: " + odb_metrics["warning"]

    base["status"] = "SUCCESS"
    base["failure_type"] = ""
    write_result(paths["results"], base)
    log_master(paths, f"Finish sample {sample.sample_id:03d} | eig1={eigenvalues[0]:.6g} | status=SUCCESS")


def parse_ids(text: str) -> List[int]:
    values = []
    for item in text.split(","):
        item = item.strip()
        if not item:
            continue
        if "-" in item:
            first, last = item.split("-", 1)
            values.extend(range(int(first), int(last) + 1))
        else:
            values.append(int(item))
    return sorted(set(values))


def main() -> None:
    parser = argparse.ArgumentParser(description="Run selected v2 linear buckling samples")
    parser.add_argument("--sample-ids", default="0", help="IDs or ranges, for example 0,1,5-7")
    parser.add_argument("--pilot", action="store_true", help="run IDs 0-4 from the official table")
    parser.add_argument("--all", action="store_true", help="explicitly select all 600 samples")
    parser.add_argument("--generate-only", action="store_true", help="write INP files without submitting Abaqus jobs")
    parser.add_argument("--retry-failed", action="store_true", help="rerun matching v2 rows whose status is FAILED")
    args = parser.parse_args()

    config = load_config()
    paths = output_paths(config)
    ensure_output_dirs(paths)
    samples = read_samples(paths["samples"])
    validate_sample_table(samples, config)
    init_results(paths["results"])
    selected = list(range(600)) if args.all else ([0, 1, 2, 3, 4] if args.pilot else parse_ids(args.sample_ids))
    if any(sample_id < 0 or sample_id >= 600 for sample_id in selected):
        raise ValueError("sample IDs must be in 0..599")
    existing = records_by_id(paths["results"])
    sha = config_sha256()
    log_master(paths, f"v2 selected={selected} | total_table=600 | existing_records={len(existing)} | generate_only={args.generate_only}")
    for sample_id in selected:
        process_sample(samples[sample_id], config, paths, sha, args.generate_only, args.retry_failed, existing)
        if not args.generate_only:
            existing = records_by_id(paths["results"])
    log_master(paths, "v2 pipeline finished for selected samples")


if __name__ == "__main__":
    main()
