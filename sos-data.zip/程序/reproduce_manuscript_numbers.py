"""Recalculate supported manuscript numbers from the retained original data."""
from pathlib import Path
import csv, collections, importlib.util, io, json, math, statistics

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'复算结果'

def read(name):
    p=next(ROOT.rglob(name));b=p.read_bytes()
    for enc in ('utf-8-sig','gb18030','cp1252'):
        try:return list(csv.DictReader(io.StringIO(b.decode(enc))))
        except UnicodeError:pass
    raise ValueError(str(p))

def write(name,rows):
    with (OUT/name).open('w',encoding='utf-8-sig',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)

def main():
    OUT.mkdir(exist_ok=True)
    mainrows=read('results_v2_1.csv');directed=read('directed_scan_merged_results.csv')
    modes=read('mode_signatures_600_points.csv');thresholds=read('Table8_layer_thresholds.csv')
    baseline=read('inner_equivalent_2_5_2_0_buckle_result.csv')[0]
    rep=read('representative_design_linear_results.csv')[0]
    smooth=read('equal_mass_smooth_buckle_result.csv')[0]
    assert len(mainrows)==600 and len(directed)==120
    assert all(x['status']=='SUCCESS' for x in mainrows)
    # Fit the power law in log space, without using manuscript coefficients.
    xx=[];yy=[]
    for r in mainrows:
        t=float(r['tmin_mm']);s=float(r['s_amplitude_mm'])
        xx.append(math.log((t**3+6*t*s*s)**(1/3)))
        yy.append(math.log(float(r['eigenvalue_1'])))
    xm=statistics.mean(xx);ym=statistics.mean(yy)
    exponent=sum((x-xm)*(y-ym) for x,y in zip(xx,yy))/sum((x-xm)**2 for x in xx)
    coefficient=math.exp(ym-exponent*xm)
    actual=[float(r['eigenvalue_1']) for r in mainrows]
    pred=[coefficient*math.exp(x*exponent) for x in xx]
    mean=statistics.mean(actual)
    r2=1-sum((a-p)**2 for a,p in zip(actual,pred))/sum((a-mean)**2 for a in actual)
    family=[];layerstats=[]
    for layer in sorted({r['tavg_target_mm'] for r in directed},key=float):
        a=[r for r in directed if r['tavg_target_mm']==layer]
        mm=[float(r['mass_kg']) for r in a]
        layerstats.append({'tavg_mm':layer,'n_designs':len(a),'mass_min_kg':min(mm),'mass_max_kg':max(mm),'mass_range_pct':(max(mm)/min(mm)-1)*100})
        for n in sorted({r['N'] for r in a},key=int):
            rr=sorted([r for r in a if r['N']==n],key=lambda r:float(r['s_amplitude_mm']))
            gain=(float(rr[-1]['eigenvalue_1'])/float(rr[0]['eigenvalue_1'])-1)*100
            family.append({'tavg_mm':layer,'N':n,'reference_ID':rr[0]['ID'],'last_ID':rr[-1]['ID'],'reference_P_MPa':rr[0]['eigenvalue_1'],'last_P_MPa':rr[-1]['eigenvalue_1'],'gain_pct':gain})
    confusion=collections.Counter();classified=[]
    for r in modes:
        t=float(r['tmin_mm']);s=float(r['s_amplitude_mm'])
        layer=min(thresholds,key=lambda q:abs(float(q['t_avg'])-t-s))
        predicted=3 if s/t>=float(layer['mid']) else 4
        observed=int(r['dominant_n_theta']);confusion[observed,predicted]+=1
        classified.append({'ID':r['ID'],'tavg_mm':t+s,'nearest_layer_mm':layer['t_avg'],'s_over_tmin':s/t,'threshold_s_over_tmin':layer['mid'],'actual_lobes':observed,'predicted_lobes':predicted,'correct':int(observed==predicted)})
    counts=collections.Counter(int(r['dominant_n_theta']) for r in modes)
    correct=sum(v for (a,b),v in confusion.items() if a==b)
    bmass=float(baseline['mass_kg']);rmass=float(rep['mass_kg']);bp=float(baseline['eigenvalue_1']);rp=float(rep['eigenvalue_1']);sp=float(smooth['smooth_eigenvalue_1_MPa'])
    summary=[
      {'metric':'effective_thickness_coefficient','value':coefficient},
      {'metric':'effective_thickness_exponent','value':exponent},
      {'metric':'effective_thickness_R2','value':r2},
      {'metric':'maximum_within_family_gain_pct','value':max(r['gain_pct'] for r in family)},
      {'metric':'three_lobe_count','value':counts[3]},
      {'metric':'four_lobe_count','value':counts[4]},
      {'metric':'correct_classifications','value':correct},
      {'metric':'classification_accuracy_pct','value':correct/len(modes)*100},
      {'metric':'balanced_accuracy_pct','value':50*(confusion[3,3]/counts[3]+confusion[4,4]/counts[4])},
      {'metric':'majority_baseline_pct','value':max(counts.values())/len(modes)*100},
      {'metric':'representative_mass_reduction_pct','value':(1-rmass/bmass)*100},
      {'metric':'representative_linear_gain_vs_baseline_pct','value':(rp/bp-1)*100},
      {'metric':'representative_linear_gain_vs_equal_mass_smooth_pct','value':(rp/sp-1)*100},
      {'metric':'representative_RBF_error_pct','value':abs(float(rep['surrogate_eigenvalue_1'])-rp)/float(rep['surrogate_eigenvalue_1'])*100}]
    # Verify the original controlled-sample generator reproduces the saved table.
    source=ROOT/'程序'/'01_Abaqus参数化流水线'/'prepare_controlled_study.py'
    spec=importlib.util.spec_from_file_location('source_generator',source);mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
    cfg=json.loads((source.parent/'config_v2_1.json').read_text(encoding='utf-8'))
    generated=mod.make_controlled(cfg);saved=read('samples_v2_1.csv')
    assert len(generated)==len(saved)==600
    assert all(str(g[k])==s[k] for g,s in zip(generated,saved) for k in g)
    assert correct==584
    assert round(max(r['gain_pct'] for r in family),2)==45.08
    assert round((rp/bp-1)*100,2)==19.13
    assert round((rp/sp-1)*100,2)==44.28
    assert round(r2,4)==0.9962
    write('关键结果复算.csv',summary);write('16参数族增益.csv',family);write('四层质量变化.csv',layerstats);write('600点模态判别逐点结果.csv',classified)
    for r in summary:print(r['metric'],r['value'])
    print('Saved 600-row generator: exact cell-for-cell match.')

if __name__=='__main__':main()
