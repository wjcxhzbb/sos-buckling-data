% Predict the two Table 7 corrugated designs using the original saved network.
root=fileparts(fileparts(mfilename('fullpath')));
x=load(fullfile(root,'06_代理模型','net.mat'));
Design=["Baseline";"Representative"];
tmin_mm=[2;1.25];s_mm=[1;1.75];N=[5;9];
input=[tmin_mm,s_mm,N]';
pn=mapminmax('apply',input,x.ps_input);
prediction=mapminmax('reverse',sim(x.net,pn),x.ps_output);
P_RBF_MPa=prediction(1,:)';mass_RBF_kg=prediction(2,:)';
T=table(Design,tmin_mm,s_mm,N,P_RBF_MPa,mass_RBF_kg);
assert(abs(P_RBF_MPa(2)-12.0120767469138)<1e-8);
writetable(T,fullfile(root,'04_代表设计与等质量线性对照','rbf_predictions_verified.csv'));
disp(T);
