"""Verify provenance of copied files and write the package SHA-256 inventory."""
from pathlib import Path
import hashlib
import json

ROOT = Path(__file__).resolve().parents[1]
SOURCE_MAP = ROOT / "来源清单.json"
INVENTORY = ROOT / "文件校验清单.json"


def sha256(path):
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def main():
    sources = json.loads(SOURCE_MAP.read_text(encoding="utf-8"))
    assert len({r["file"] for r in sources}) == len(sources)
    copied = 0
    for record in sources:
        path = ROOT / record["file"]
        assert path.is_file(), "missing retained file: " + record["file"]
        if record["method"] == "byte-identical copy":
            actual = sha256(path)
            assert actual == record["source_sha256"], "source hash differs: " + record["file"]
            copied += 1

    rerun = ROOT / "复算结果" / "linear_rerun_verified.csv"
    assert rerun.is_file(), "three-case fresh Abaqus rerun has not finished"
    files = []
    for path in sorted(ROOT.rglob("*")):
        if not path.is_file() or path == INVENTORY:
            continue
        relative = path.relative_to(ROOT).as_posix()
        assert "__pycache__" not in path.parts, "cache file in package: " + relative
        files.append({"file": relative, "size_bytes": path.stat().st_size, "sha256": sha256(path)})
    INVENTORY.write_text(json.dumps(files, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print("verified source-identical copies:", copied)
    print("inventoried files:", len(files))


if __name__ == "__main__":
    main()
