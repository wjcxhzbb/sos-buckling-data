"""Rerun the three retained original INP files, then check FE eigenvalues."""
from pathlib import Path
import argparse,csv,json,re,shutil,subprocess,time

def eigenvalues(p):
    text=p.read_text(encoding='utf-8',errors='replace')
    marker=text.upper().rfind('E I G E N V A L U E')
    if marker<0:raise ValueError('No eigenvalue table in '+str(p))
    vals=[]
    for line in text[marker:marker+5000].splitlines():
        m=re.match(r'^\s*([1-3])\s+([+-]?[0-9.]+(?:[EeDd][+-]?\d+)?)\s*$',line)
        if m:vals.append(float(m.group(2).replace('D','E')))
    if not vals:raise ValueError('No eigenvalue rows in '+str(p))
    return vals

def main():
    p=argparse.ArgumentParser();p.add_argument('--output',required=True);p.add_argument('--abaqus',default='abaqus');a=p.parse_args()
    root=Path(__file__).resolve().parents[1];out=Path(a.output).resolve();out.mkdir(parents=True,exist_ok=True)
    expected={'baseline':10.044,'representative':11.965,'equal_mass_smooth':8.293};rows=[]
    for label,target in expected.items():
        work=out/label;work.mkdir(exist_ok=True);src=root/'原始线性算例'/(label+'_buckle.inp');dst=work/'model.inp';shutil.copy2(src,dst)
        cmd=[a.abaqus,'job=verify_'+label,'input=model.inp','cpus=2','memory=25%','interactive']
        print('RUN',label,flush=True);start=time.monotonic()
        with (work/'solver.log').open('w',encoding='utf-8') as log:
            done=subprocess.run(subprocess.list2cmdline(cmd),cwd=work,shell=True,stdout=log,stderr=subprocess.STDOUT,timeout=1200)
        if done.returncode:raise RuntimeError('Abaqus failed: '+str(work/'solver.log'))
        values=eigenvalues(work/('verify_'+label+'.dat'))
        ok=abs(values[0]-target)<0.00051
        rows.append({'design':label,'eigenvalue_1_MPa':values[0],'manuscript_raw_reference_MPa':target,'matches_reported_precision':ok,'elapsed_seconds':time.monotonic()-start})
        print(rows[-1],flush=True)
        if not ok:raise RuntimeError('Calculated result differs; see '+str(work))
    with (out/'linear_rerun_verified.csv').open('w',encoding='utf-8-sig',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)

if __name__=='__main__':main()
