"""Read the two original Abaqus BUCKLE ODBs without modifying them."""
import argparse, cmath, csv, json, math, os, re

def extract(path,label,outdir):
    from odbAccess import openOdb
    odb=openOdb(path=path,readOnly=True)
    try:
        inst=odb.rootAssembly.instances['MODEL_INST']
        frame=odb.steps['BUCKLE'].frames[1]
        disp={v.nodeLabel:tuple(float(t) for t in v.data) for v in frame.fieldOutputs['U'].values}
        rings={}
        for nd in inst.nodeSets['SHELL_NODES'].nodes:
            x,y,z=[float(v) for v in nd.coordinates];r=math.hypot(x,y)
            if abs(r-75.0)>0.001:continue
            u=disp[nd.label];theta=math.atan2(y,x)%(2*math.pi)
            rings.setdefault(round(z,6),[]).append((theta,(u[0]*x+u[1]*y)/r))
        zs=sorted(rings);grid=[[u for th,u in sorted(rings[z])] for z in zs]
        ntheta=len(grid[0]);assert all(len(row)==ntheta for row in grid)
        scale=max(abs(u) for row in grid for u in row)
        ring=max(range(len(grid)),key=lambda k:sum(u*u for u in grid[k]))
        signal=grid[ring];mean=sum(signal)/ntheta
        amps=[abs(sum((u-mean)*cmath.exp(-2j*math.pi*n*j/ntheta) for j,u in enumerate(signal)))*2/ntheta for n in range(1,13)]
        dominant=1+max(range(12),key=lambda k:amps[k])
        m=re.search(r'EigenValue\s*=\s*([0-9.eE+-]+)',frame.description)
        result={'design':label,'eigenvalue_1_MPa':float(m.group(1)),'dominant_n_theta':dominant,
                'ring_z_mm':zs[ring],'axial_rings':len(zs),'circumferential_nodes':ntheta,
                'source_odb':os.path.abspath(path),'frame_description':frame.description}
        with open(os.path.join(outdir,label+'_mode1_outer.csv'),'w',newline='') as f:
            w=csv.writer(f);w.writerow(['z_mm']+['th%03d'%j for j in range(ntheta)])
            for z,row in zip(zs,grid):w.writerow(['%.6f'%z]+['%.8g'%(u/scale) for u in row])
        return result
    finally:odb.close()

def main():
    p=argparse.ArgumentParser();p.add_argument('--baseline-odb',required=True);p.add_argument('--representative-odb',required=True);p.add_argument('--smooth-odb');p.add_argument('--output',required=True)
    a=p.parse_args();os.makedirs(a.output,exist_ok=True)
    results=[extract(a.baseline_odb,'baseline',a.output),extract(a.representative_odb,'representative',a.output)]
    assert [r['dominant_n_theta'] for r in results]==[4,3]
    if a.smooth_odb:
        smooth=extract(a.smooth_odb,'equal_mass_smooth',a.output)
        results.append(smooth)
        assert smooth['dominant_n_theta']==4
    with open(os.path.join(a.output,'mode_extraction_verified.json'),'w',encoding='utf-8') as f:json.dump(results,f,ensure_ascii=False,indent=2)
    print(json.dumps(results,ensure_ascii=False))

if __name__=='__main__':main()
